﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital.Windows
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        Entities db = Helper.GetContext();       
        public Registration()
        {
            InitializeComponent();
            var querry = db.RegistrationForAnAppointment;
            dtg_RegistrationForAnAppointment.ItemsSource = querry.ToList();
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            RegistrationForAnAppointment selectedItem = dtg_RegistrationForAnAppointment.SelectedItem as RegistrationForAnAppointment;
            if (selectedItem == null)
            {
                MessageBox.Show("Выберите запись!");
            }
            else if (MessageBox.Show("Вы действительно хотите удалить запись?", "Предупреждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                DbSet<RegistrationForAnAppointment> items = db.RegistrationForAnAppointment;
                items.Remove(selectedItem);
                db.SaveChanges();
                refresh();

            }
        }
        public void refresh()
        {
            InitializeComponent();
            var querry = db.RegistrationForAnAppointment;
            dtg_RegistrationForAnAppointment.ItemsSource = querry.ToList();
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            AddRegistrationForAnAppointment ordersWindow = new AddRegistrationForAnAppointment();
            ordersWindow.Show();
            refresh();
        }

        private void btn_red_Click(object sender, RoutedEventArgs e)
        {
            RegistrationForAnAppointment selectedItem = dtg_RegistrationForAnAppointment.SelectedItem as RegistrationForAnAppointment;

            if (selectedItem == null)
            {
                MessageBox.Show("Выберите запись!");
            }
            else if (MessageBox.Show("Вы действительно хотите изменить запись?", "Предупреждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    db.Entry(selectedItem).State = EntityState.Modified;
                    db.SaveChanges();
                    refresh();
                }
                catch
                {
                    MessageBox.Show("Введены некорректные данные!");
                }
            }
        }

        private void btn_back(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}


