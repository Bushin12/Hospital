﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddRegistrationForAnAppointment.xaml
    /// </summary>
    public partial class AddRegistrationForAnAppointment : Window
    {
        Entities db = Helper.GetContext();
        public AddRegistrationForAnAppointment()
        {
            InitializeComponent();
        }
            private void btn_config_Click(object sender, RoutedEventArgs e)
            {
                try
                {
                    DateTime date_start = DateTime.Parse(tb_time_start.Text.ToString());
                    RegistrationForAnAppointment newReg = new RegistrationForAnAppointment();
                    newReg.TimeAppointment = date_start;
                    newReg.IdEmployee = int.Parse(tb_Employee.Text);
                    newReg.IdPatient= int.Parse(tb_Patient.Text);
                    Create(newReg);
                    MessageBox.Show("Сохранение успешно!");
                    Close();

                }
                catch
                {
                    MessageBox.Show("Введены некорректные данные!");
                }
            }
            public void Create(RegistrationForAnAppointment orders)
            {
                db.RegistrationForAnAppointment.Add(orders);
                db.SaveChanges();
            }


            private void btn_back_Click(object sender, RoutedEventArgs e)
            {
                Close();
            }
        }
    }
